
#' Escenario adverso ARIMA con perfil de shock k_h
#'
#' La función toma un modelo ARIMA ya estimado y construye un escenario baseline
#' con `forecast::forecast`. El escenario adverso se define como baseline más
#' k_h veces la desviación estándar de los residuos del modelo.
#'
#' @param modelo_arima Modelo estimado compatible con `forecast::forecast`.
#' @param k_h Vector con el perfil temporal del shock. Su longitud define h, salvo que se indique `h`.
#' @param h Horizonte de proyección. Por defecto `length(k_h)`.
#' @param nombre_variable Etiqueta de la variable graficada.
#' @param tasa_nominal Vector opcional para computar tasa real baseline/adversa.
#' @param sigma Shock unitario. Si es NULL, usa sd(residuals(modelo_arima)).
#' @param nivel_confianza Nivel de intervalo para forecast.
#' @return Lista con `escenarios` y `grafico`.
escenario_arima_shock <- function(modelo_arima,
                                  k_h,
                                  h = length(k_h),
                                  nombre_variable = "variable",
                                  tasa_nominal = NULL,
                                  sigma = NULL,
                                  nivel_confianza = 95) {
  if (length(k_h) < h) stop("k_h debe tener al menos h elementos.")
  k_h <- as.numeric(k_h[seq_len(h)])

  fc <- forecast::forecast(modelo_arima, h = h, level = nivel_confianza)
  baseline <- as.numeric(fc$mean)

  if (is.null(sigma)) sigma <- stats::sd(stats::residuals(modelo_arima), na.rm = TRUE)
  shock <- k_h * sigma
  adverso <- baseline + shock

  escenarios <- tibble::tibble(
    horizonte = seq_len(h),
    variable = nombre_variable,
    baseline = baseline,
    k_h = k_h,
    sigma = sigma,
    shock = shock,
    adverso = adverso
  )

  if (!is.null(tasa_nominal)) {
    if (length(tasa_nominal) == 1) tasa_nominal <- rep(tasa_nominal, h)
    if (length(tasa_nominal) < h) stop("tasa_nominal debe tener longitud 1 o al menos h.")
    escenarios$tasa_nominal <- as.numeric(tasa_nominal[seq_len(h)])
    escenarios$tasa_real_baseline <- escenarios$tasa_nominal - escenarios$baseline
    escenarios$tasa_real_adversa <- escenarios$tasa_nominal - escenarios$adverso
  }

  plot_df <- escenarios |>
    dplyr::select(.data$horizonte, .data$baseline, .data$adverso) |>
    tidyr::pivot_longer(cols = c("baseline", "adverso"),
                        names_to = "escenario",
                        values_to = "valor")

  grafico <- ggplot2::ggplot(plot_df, ggplot2::aes(x = .data$horizonte, y = .data$valor,
                                                   color = .data$escenario)) +
    ggplot2::geom_line(linewidth = 1.1) +
    ggplot2::geom_point(size = 1.8) +
    ggplot2::labs(
      title = paste0(nombre_variable, ": baseline vs escenario adverso"),
      subtitle = "Adverso = baseline + k_h * sigma(residuos ARIMA)",
      x = "Horizonte",
      y = nombre_variable,
      color = "Escenario"
    ) +
    ggplot2::theme_minimal()

  list(escenarios = escenarios, grafico = grafico, forecast = fc)
}
