# macropenstress 0.1.0

- Carga de base macro-previsional del curso desde CSV incluido.
- Función `escenario_arima_shock()` para escenarios baseline/adverso con perfil k_h.
- Función `escenario_var_stress()` con enfoques marginal, trayectoria conjunta extrema y VAR condicional.
- Función auxiliar `forecast_var_condicional()`.
- Ejemplos originales del curso incluidos en `inst/examples`.
