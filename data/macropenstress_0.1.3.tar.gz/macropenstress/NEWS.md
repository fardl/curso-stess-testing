## macropenstress 0.1.3

- `escenario_var_stress()` ahora permite pasar `severity_by_path`, un vector de severidad precomputado por simulación para seleccionar trayectorias conjuntas extremas definidas por el usuario.

## macropenstress 0.1.2

- Ajusta el gráfico de `escenario_var_stress()` para presentar histórico, baseline y escenarios adversos en un único eje temporal por variable.
- Elimina la separación por columnas de enfoque y ancla todas las trayectorias futuras en el último dato histórico para mostrar continuidad temporal.
- Agrega `datos_grafico` al objeto de salida para facilitar auditoría y personalización del gráfico.

# macropenstress 0.1.0

- Carga de base macro-previsional del curso desde CSV incluido.
- Función `escenario_arima_shock()` para escenarios baseline/adverso con perfil k_h.
- Función `escenario_var_stress()` con enfoques marginal, trayectoria conjunta extrema y VAR condicional.
- Función auxiliar `forecast_var_condicional()`.
- Ejemplos originales del curso incluidos en `inst/examples`.
